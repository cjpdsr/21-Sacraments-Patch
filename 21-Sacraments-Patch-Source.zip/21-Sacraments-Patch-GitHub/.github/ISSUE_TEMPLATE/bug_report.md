---
name: Bug or performance report
about: Report a reproducible problem with build and settings context
---

Game build / executable hash:
Patch version:
GPU / VRAM / driver:
CPU / RAM:
Upscaler / frame generation / VSync / frame cap / graphics settings:
Other mods or overlays:

Location and steps:
Behavior with budget ON vs OFF:
First pass vs repeated pass:
Relevant sanitized log excerpts / measurements:
Any lighting, reflection, geometry or stability changes:
